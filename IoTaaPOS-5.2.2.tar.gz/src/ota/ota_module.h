#ifndef __OTA_MODULE_H__
#define __OTA_MODULE_H__

#include "./system/system_init.h"

void handleUpdates();
void checkUpdate();
void otaUpdate();

#endif