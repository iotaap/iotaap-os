#ifndef __SYSTEM_INIT_H__
#define __SYSTEM_INIT_H__

#include <Arduino.h>

void systemInit();
void systemInfo();

#endif