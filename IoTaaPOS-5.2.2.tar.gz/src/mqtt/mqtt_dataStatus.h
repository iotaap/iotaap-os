#ifndef __MQTT_DATASTATUS_H__
#define __MQTT_DATASTATUS_H__

void publishSystemStatus();

#endif