# Micro SD card FS library for ESP32

Based on: [esp32-micro-sdcard](https://github.com/geeksville/esp32-micro-sdcard)