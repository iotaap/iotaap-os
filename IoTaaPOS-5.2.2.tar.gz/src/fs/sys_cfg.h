#ifndef __SYS_CFG_H__
#define __SYS_CFG_H__

#include <stdint.h>

int InitSystemParameters( void);

#endif
