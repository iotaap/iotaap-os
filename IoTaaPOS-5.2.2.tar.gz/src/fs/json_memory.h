#ifndef __JSON_MEMORY_H_
#define __JSON_MEMORY_H_

#include "FFat.h"

int CalculateDynamicMemorySizeForJson( fs::File JsonOpenedfile);

#endif