---
name: Feature Request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

**Please refer to our community to check, discuss and suggest new features and improvements**
- [IoTaaP Community - Features](https://community.iotaap.io/c/iotaap-os/features)
